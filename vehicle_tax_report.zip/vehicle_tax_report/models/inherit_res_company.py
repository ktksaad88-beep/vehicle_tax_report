from odoo import models, fields, _, api


class ResCompany(models.Model):
    _inherit = 'res.company'

    acc_holder_name = fields.Char(string='Acc Holder Name')
    bank_name = fields.Char(string='Bank Name')
    iban_no = fields.Char(string='IBAN No')
    branch_name = fields.Char(string='Branch Name')
    account_number = fields.Char(string='Account Number')
    ifsc_code = fields.Char(string='Swift Code')
