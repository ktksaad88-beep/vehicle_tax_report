{
    'name': 'Vehicle Tax Report',
    'version': '17.0.0.2',
    'category': 'Reporting',
    'summary': 'Custom 2-page PDF report',
    'description': 'This module generates a 2-page PDF report.',
    'author': 'Asim Umer',
    'website': 'https://yourcompany.example.com',
    'depends': ['base', 'web', 'sale','vehicle_rental'],
    'data': [
        'views/inherit_res_company.xml',
        'report/vehicle_rental_template.xml',
        'report/vehicle_rental_action.xml',

    ],
    'installable': True,
    'application': False,
    'auto_install': False,
    'license': 'LGPL-3',
}
